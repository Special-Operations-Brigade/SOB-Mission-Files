// 3AS
force TAS_fullShieldTime = 30;
force TAS_jetcoolset = 1;
force TAS_jetfuelset = 1;
force TAS_jetheatset = 1;
force TAS_jetsoundvol = 0.6;
force TAS_lcLoadDist = 20;
force TAS_lcLoadSpeed = 10;
force TAS_shieldTime = 30;
force TAS_SquadShieldTime = 180;

// 3AS Shields
force TAS_DroidekaDisabledShieldTime = 0.75;
force TAS_DroidekaShieldsRegenDisabled = true;

// ACE Advanced Ballistics
force ace_advanced_ballistics_ammoTemperatureEnabled = false;
force ace_advanced_ballistics_barrelLengthInfluenceEnabled = false;
force ace_advanced_ballistics_bulletTraceEnabled = true;
force ace_advanced_ballistics_enabled = false;
force ace_advanced_ballistics_muzzleVelocityVariationEnabled = false;
force ace_advanced_ballistics_simulationInterval = 0.05;

// ACE Advanced Throwing
force ace_advanced_throwing_enabled = true;
force ace_advanced_throwing_enablePickUp = true;
force ace_advanced_throwing_enablePickUpAttached = true;
force ace_advanced_throwing_showMouseControls = true;
force ace_advanced_throwing_showThrowArc = true;

// ACE Advanced Vehicle Damage
force ace_vehicle_damage_enableCarDamage = false;
force ace_vehicle_damage_enabled = false;
force ace_vehicle_damage_removeAmmoDuringCookoff = false;

// ACE AI
force ace_ai_assignNVG = true;

// ACE Arsenal
force ace_arsenal_allowDefaultLoadouts = true;
force ace_arsenal_allowSharedLoadouts = true;
force ace_arsenal_camInverted = false;
ace_arsenal_defaultToFavorites = false;
force ace_arsenal_enableIdentityTabs = false;
force ace_arsenal_enableModIcons = true;
force ace_arsenal_EnableRPTLog = false;
ace_arsenal_favoritesColor = [0.0293119,0.576074,0.801543];
force ace_arsenal_fontHeight = 4.5;
force ace_arsenal_loadoutsSaveFace = false;
force ace_arsenal_loadoutsSaveInsignia = true;
force ace_arsenal_loadoutsSaveVoice = false;

// ACE Artillery
force ace_artillerytables_advancedCorrections = false;
force ace_artillerytables_disableArtilleryComputer = true;
force ace_mk6mortar_airResistanceEnabled = false;
force ace_mk6mortar_allowCompass = true;
force ace_mk6mortar_allowComputerRangefinder = false;
force ace_mk6mortar_useAmmoHandling = false;

// ACE Captives
force ace_captives_allowHandcuffOwnSide = true;
force ace_captives_allowSurrender = true;
force ace_captives_requireSurrender = 1;
force ace_captives_requireSurrenderAi = false;

// ACE Casings
force ace_casings_enabled = false;
force ace_casings_maxCasings = 250;

// ACE Common
force ace_common_allowFadeMusic = true;
force ace_common_checkPBOsAction = 0;
force ace_common_checkPBOsCheckAll = false;
force ace_common_checkPBOsWhitelist = "[]";
force ace_common_displayTextColor = [0,0,0,0.1];
force ace_common_displayTextFontColor = [1,1,1,1];
ace_common_epilepsyFriendlyMode = false;
ace_common_progressBarInfo = 2;
force ace_common_settingFeedbackIcons = 1;
force ace_common_settingProgressBarLocation = 0;

// ACE Cook off
force ace_cookoff_ammoCookoffDuration = 0;
force ace_cookoff_destroyVehicleAfterCookoff = false;
force ace_cookoff_enable = 2;
force ace_cookoff_enableAmmobox = false;
force ace_cookoff_enableAmmoCookoff = false;
force ace_cookoff_enableFire = true;
force ace_cookoff_probabilityCoef = 0.4;

// ACE Crew Served Weapons
force ace_csw_ammoHandling = 2;
force ace_csw_defaultAssemblyMode = false;
force ace_csw_dragAfterDeploy = true;
force ace_csw_handleExtraMagazines = false;
force ace_csw_handleExtraMagazinesType = 0;
force ace_csw_progressBarTimeCoefficent = 1;

// ACE Dragging
force ace_dragging_allowRunWithLightweight = true;
force ace_dragging_dragAndFire = true;
force ace_dragging_skipContainerWeight = true;
force ace_dragging_weightCoefficient = 0.25;

// ACE Explosives
force ace_explosives_customTimerDefault = 30;
force ace_explosives_customTimerMax = 3600;
force ace_explosives_customTimerMin = 5;
force ace_explosives_explodeOnDefuse = true;
force ace_explosives_punishNonSpecialists = true;
force ace_explosives_requireSpecialist = true;

// ACE Field Rations
force acex_field_rations_affectAdvancedFatigue = false;
force acex_field_rations_enabled = false;
force acex_field_rations_hudShowLevel = 0;
force acex_field_rations_hudTransparency = -1;
force acex_field_rations_hudType = 0;
force acex_field_rations_hungerSatiated = 1;
force acex_field_rations_terrainObjectActions = false;
force acex_field_rations_thirstQuenched = 1;
force acex_field_rations_timeWithoutFood = 2;
force acex_field_rations_timeWithoutWater = 2;
force acex_field_rations_waterSourceActions = 2;

// ACE Fire
force ace_fire_dropWeapon = 1;
force ace_fire_enabled = true;
force ace_fire_enableFlare = true;
force ace_fire_enableScreams = true;

// ACE Fortify
force ace_fortify_markObjectsOnMap = 1;
force ace_fortify_timeCostCoefficient = 1;
force ace_fortify_timeMin = 1.5;
force acex_fortify_settingHint = 1;

// ACE Fragmentation Simulation
force ace_frag_enabled = true;
force ace_frag_maxTrack = 5;
force ace_frag_maxTrackPerFrame = 5;
force ace_frag_reflectionsEnabled = true;
force ace_frag_spallEnabled = true;

// ACE G-Forces
force ace_gforces_coef = 1;
force ace_gforces_enabledFor = 0;

// ACE Goggles
ace_goggles_effects = 2;
force ace_goggles_showClearGlasses = true;
force ace_goggles_showInThirdPerson = false;

// ACE Grenades
force ace_grenades_convertExplosives = true;

// ACE Headless
force acex_headless_delay = 10;
force acex_headless_enabled = true;
force acex_headless_endMission = 0;
force acex_headless_log = true;
force acex_headless_transferLoadout = 1;

// ACE Hearing
force ace_hearing_autoAddEarplugsToUnits = false;
force ace_hearing_disableEarRinging = true;
force ace_hearing_earplugsVolume = 0.5;
force ace_hearing_enableCombatDeafness = true;
force ace_hearing_enabledForZeusUnits = false;
force ace_hearing_unconsciousnessVolume = 0.4;

// ACE Interaction
force ace_interaction_disableNegativeRating = true;
force ace_interaction_enableGroupRenaming = true;
force ace_interaction_enableMagazinePassing = true;
force ace_interaction_enableTeamManagement = true;
force ace_interaction_enableWeaponAttachments = true;
force ace_interaction_interactWithTerrainObjects = false;

// ACE Interaction Menu
ace_gestures_showOnInteractionMenu = 2;
ace_interact_menu_actionOnKeyRelease = true;
force ace_interact_menu_addBuildingActions = true;
ace_interact_menu_alwaysUseCursorInteraction = true;
ace_interact_menu_alwaysUseCursorSelfInteraction = true;
ace_interact_menu_colorShadowMax = [0,0,0,1];
ace_interact_menu_colorShadowMin = [0,0,0,0.25];
ace_interact_menu_colorTextMax = [1,1,1,1];
ace_interact_menu_colorTextMin = [1,1,1,0.25];
ace_interact_menu_consolidateSingleChild = false;
ace_interact_menu_cursorKeepCentered = false;
ace_interact_menu_cursorKeepCenteredSelfInteraction = false;
ace_interact_menu_menuAnimationSpeed = 0;
ace_interact_menu_menuBackground = 0;
ace_interact_menu_menuBackgroundSelf = 0;
ace_interact_menu_selectorColor = [0.96,0.71,0];
ace_interact_menu_shadowSetting = 2;
ace_interact_menu_textSize = 2;
ace_interact_menu_useListMenu = true;
ace_interact_menu_useListMenuSelf = true;

// ACE Logistics
ace_cargo_carryAfterUnload = true;
force ace_cargo_enable = true;
force ace_cargo_enableRename = true;
force ace_cargo_loadTimeCoefficient = 5;
force ace_cargo_openAfterUnload = 3;
force ace_cargo_paradropTimeCoefficent = 0.2;
force ace_rearm_distance = 20;
force ace_rearm_enabled = true;
force ace_rearm_level = 0;
force ace_rearm_supply = 0;
force ace_refuel_cargoRate = 10;
force ace_refuel_hoseLength = 12;
force ace_refuel_progressDuration = 2;
force ace_refuel_rate = 1;
force ace_towing_addRopeToVehicleInventory = true;

// ACE Magazine Repack
ace_magazinerepack_repackAnimation = true;
force ace_magazinerepack_repackLoadedMagazines = true;
force ace_magazinerepack_timePerAmmo = 1;
force ace_magazinerepack_timePerBeltLink = 8;
force ace_magazinerepack_timePerMagazine = 1;

// ACE Map
force ace_map_BFT_Enabled = false;
force ace_map_BFT_HideAiGroups = true;
force ace_map_BFT_Interval = 30;
force ace_map_BFT_ShowPlayerNames = false;
force ace_map_DefaultChannel = 1;
force ace_map_mapGlow = true;
force ace_map_mapIllumination = true;
force ace_map_mapLimitZoom = false;
force ace_map_mapShake = false;
force ace_map_mapShowCursorCoordinates = false;
force ace_markers_moveRestriction = 0;
force ace_markers_timestampEnabled = false;
force ace_markers_timestampFormat = "HH:MM";
force ace_markers_timestampHourFormat = 24;
ace_markers_timestampTimezone = 0;
ace_markers_TimestampUTCMinutesOffset = 0;
ace_markers_timestampUTCOffset = 0;

// ACE Map Gestures
ace_map_gestures_allowCurator = true;
force ace_map_gestures_allowSpectator = true;
force ace_map_gestures_briefingMode = 0;
force ace_map_gestures_defaultColor = [1,0.88,0,0.7];
force ace_map_gestures_defaultLeadColor = [1,0.88,0,0.95];
force ace_map_gestures_enabled = true;
force ace_map_gestures_interval = 0.03;
force ace_map_gestures_maxRange = 50;
force ace_map_gestures_maxRangeCamera = 14;
force ace_map_gestures_nameTextColor = [0.2,0.2,0.2,0.3];
force ace_map_gestures_onlyShowFriendlys = false;

// ACE Map Tools
force ace_maptools_drawStraightLines = true;
ace_maptools_plottingBoardAllowChannelDrawing = 1;
force ace_maptools_rotateModifierKey = 1;

// ACE Medical
force ace_medical_ai_enabledFor = 2;
force ace_medical_ai_requireItems = 2;
force ace_medical_AIDamageThreshold = 1;
force ace_medical_bleedingCoefficient = 0.3;
force ace_medical_blood_bloodLifetime = 600;
force ace_medical_blood_enabledFor = 2;
force ace_medical_blood_maxBloodObjects = 500;
force ace_medical_deathChance = 0.15;
force ace_medical_dropWeaponUnconsciousChance = 0;
force ace_medical_enableVehicleCrashes = false;
force ace_medical_engine_damagePassThroughEffect = 1;
force ace_medical_fatalDamageSource = 1;
force ace_medical_fractureChance = 0.15;
force ace_medical_fractures = 1;
force ace_medical_ivFlowRate = 1;
force ace_medical_limping = 1;
force ace_medical_painCoefficient = 1.5;
force ace_medical_painUnconsciousChance = 0.1;
force ace_medical_painUnconsciousThreshold = 0.85;
force ace_medical_playerDamageThreshold = 2;
force ace_medical_spontaneousWakeUpChance = 0.25;
force ace_medical_spontaneousWakeUpEpinephrineBoost = 4;
force ace_medical_statemachine_AIUnconsciousness = true;
force ace_medical_statemachine_cardiacArrestBleedoutEnabled = true;
force ace_medical_statemachine_cardiacArrestTime = 900;
force ace_medical_statemachine_fatalInjuriesAI = 0;
force ace_medical_statemachine_fatalInjuriesPlayer = 1;
force ace_medical_treatment_advancedBandages = 2;
force ace_medical_treatment_advancedDiagnose = 1;
force ace_medical_treatment_advancedMedication = true;
force ace_medical_treatment_allowBodyBagUnconscious = true;
force ace_medical_treatment_allowGraveDigging = 2;
force ace_medical_treatment_allowLitterCreation = true;
force ace_medical_treatment_allowSelfIV = 1;
force ace_medical_treatment_allowSelfPAK = 1;
force ace_medical_treatment_allowSelfStitch = 1;
force ace_medical_treatment_allowSharedEquipment = 0;
force ace_medical_treatment_bandageEffectiveness = 1;
force ace_medical_treatment_bandageRollover = true;
force ace_medical_treatment_clearTrauma = 0;
force ace_medical_treatment_consumePAK = 0;
force ace_medical_treatment_consumeSurgicalKit = 2;
force ace_medical_treatment_convertItems = 0;
force ace_medical_treatment_cprSuccessChanceMax = 0.8;
force ace_medical_treatment_cprSuccessChanceMin = 0.1;
force ace_medical_treatment_graveDiggingMarker = true;
force ace_medical_treatment_holsterRequired = 0;
force ace_medical_treatment_litterCleanupDelay = 240;
force ace_medical_treatment_locationEpinephrine = 0;
force ace_medical_treatment_locationIV = 0;
force ace_medical_treatment_locationPAK = 3;
force ace_medical_treatment_locationsBoostTraining = false;
force ace_medical_treatment_locationSurgicalKit = 0;
force ace_medical_treatment_maxLitterObjects = 300;
force ace_medical_treatment_medicEpinephrine = 0;
force ace_medical_treatment_medicIV = 1;
force ace_medical_treatment_medicPAK = 2;
force ace_medical_treatment_medicSurgicalKit = 1;
force ace_medical_treatment_timeCoefficientPAK = 0.1;
force ace_medical_treatment_treatmentTimeAutoinjector = 2;
force ace_medical_treatment_treatmentTimeBodyBag = 10;
ace_medical_treatment_treatmentTimeCoeffZeus = 1;
force ace_medical_treatment_treatmentTimeCPR = 15;
force ace_medical_treatment_treatmentTimeGrave = 20;
force ace_medical_treatment_treatmentTimeIV = 8;
force ace_medical_treatment_treatmentTimeSplint = 7;
force ace_medical_treatment_treatmentTimeTourniquet = 3;
force ace_medical_treatment_woundReopenChance = 1;
force ace_medical_treatment_woundStitchTime = 3;

// ACE Medical Interface
ace_medical_feedback_bloodVolumeEffectType = 0;
force ace_medical_feedback_enableHUDIndicators = true;
ace_medical_feedback_painEffectType = 0;
ace_medical_gui_bloodLossColor_0 = [1,1,1,1];
ace_medical_gui_bloodLossColor_1 = [1,0.95,0.64,1];
ace_medical_gui_bloodLossColor_2 = [1,0.87,0.46,1];
ace_medical_gui_bloodLossColor_3 = [1,0.8,0.33,1];
ace_medical_gui_bloodLossColor_4 = [1,0.72,0.24,1];
ace_medical_gui_bloodLossColor_5 = [1,0.63,0.15,1];
ace_medical_gui_bloodLossColor_6 = [1,0.54,0.08,1];
ace_medical_gui_bloodLossColor_7 = [1,0.43,0.02,1];
ace_medical_gui_bloodLossColor_8 = [1,0.3,0,1];
ace_medical_gui_bloodLossColor_9 = [1,0,0,1];
ace_medical_gui_bodyPartOutlineColor = [1,1,1,1];
ace_medical_gui_damageColor_0 = [1,1,1,1];
ace_medical_gui_damageColor_1 = [0.75,0.95,1,1];
ace_medical_gui_damageColor_2 = [0.62,0.86,1,1];
ace_medical_gui_damageColor_3 = [0.54,0.77,1,1];
ace_medical_gui_damageColor_4 = [0.48,0.67,1,1];
ace_medical_gui_damageColor_5 = [0.42,0.57,1,1];
ace_medical_gui_damageColor_6 = [0.37,0.47,1,1];
ace_medical_gui_damageColor_7 = [0.31,0.36,1,1];
ace_medical_gui_damageColor_8 = [0.22,0.23,1,1];
ace_medical_gui_damageColor_9 = [0,0,1,1];
force ace_medical_gui_enableActions = 0;
force ace_medical_gui_enableMedicalMenu = 1;
force ace_medical_gui_enableSelfActions = true;
force ace_medical_gui_interactionMenuShowTriage = 1;
force ace_medical_gui_maxDistance = 3;
force ace_medical_gui_openAfterTreatment = true;
force ace_medical_gui_peekMedicalInfoReleaseDelay = 0;
force ace_medical_gui_peekMedicalOnHit = false;
force ace_medical_gui_peekMedicalOnHitDuration = 0;
force ace_medical_gui_showBloodlossEntry = true;
force ace_medical_gui_showDamageEntry = false;
ace_medical_gui_tourniquetWarning = true;

// ACE Name Tags
force ace_nametags_ambientBrightnessAffectViewDist = 1;
force ace_nametags_defaultNametagColor = [0.77,0.51,0.08,1];
ace_nametags_nametagColorBlue = [0.27,0.53,0.95,1];
ace_nametags_nametagColorGreen = [0.11,0.64,0.38,1];
ace_nametags_nametagColorMain = [1,1,1,1];
ace_nametags_nametagColorRed = [0.85,0.13,0.15,1];
ace_nametags_nametagColorYellow = [1,0.81,0.29,1];
force ace_nametags_playerNamesMaxAlpha = 0.8;
force ace_nametags_playerNamesViewDistance = 50;
force ace_nametags_showCursorTagForVehicles = true;
force ace_nametags_showNamesForAI = false;
force ace_nametags_showPlayerNames = 0;
force ace_nametags_showPlayerRanks = false;
force ace_nametags_showSoundWaves = 1;
force ace_nametags_showVehicleCrewInfo = true;
force ace_nametags_tagSize = 2;

// ACE Nightvision
force ace_nightvision_aimDownSightsBlur = 0.05;
force ace_nightvision_disableNVGsWithSights = false;
force ace_nightvision_effectScaling = 0.05;
force ace_nightvision_fogScaling = 0.05;
force ace_nightvision_noiseScaling = 0;
force ace_nightvision_shutterEffects = true;

// ACE Overheating
force ace_overheating_cookoffCoef = 0;
force ace_overheating_coolingCoef = 1;
force ace_overheating_displayTextOnJam = true;
force ace_overheating_enabled = true;
force ace_overheating_heatCoef = 0.2;
force ace_overheating_jamChanceCoef = 0.4;
force ace_overheating_overheatingDispersion = true;
force ace_overheating_overheatingRateOfFire = false;
force ace_overheating_particleEffectsAndDispersionDistance = 3000;
force ace_overheating_showParticleEffects = true;
force ace_overheating_showParticleEffectsForEveryone = false;
force ace_overheating_suppressorCoef = 1;
force ace_overheating_unJamFailChance = 0;
force ace_overheating_unJamOnreload = false;
force ace_overheating_unJamOnSwapBarrel = false;

// ACE Pointing
force ace_finger_enabled = true;
force ace_finger_indicatorColor = [0.83,0.68,0.21,0.75];
force ace_finger_indicatorForSelf = true;
force ace_finger_maxRange = 50;
force ace_finger_proximityScaling = false;
force ace_finger_sizeCoef = 1;

// ACE Pylons
force ace_pylons_enabledForZeus = true;
force ace_pylons_enabledFromAmmoTrucks = true;
force ace_pylons_rearmNewPylons = true;
force ace_pylons_requireEngineer = false;
force ace_pylons_requireToolkit = false;
force ace_pylons_searchDistance = 15;
force ace_pylons_timePerPylon = 5;

// ACE Quick Mount
force ace_quickmount_distance = 5;
force ace_quickmount_enabled = true;
force ace_quickmount_enableMenu = 3;
force ace_quickmount_priority = 3;
force ace_quickmount_speed = 18;

// ACE Repair
force ace_repair_addSpareParts = true;
force ace_repair_autoShutOffEngineWhenStartingRepair = true;
force ace_repair_consumeItem_toolKit = 0;
force ace_repair_displayTextOnRepair = true;
force ace_repair_enabled = true;
force ace_repair_engineerSetting_fullRepair = 1;
force ace_repair_engineerSetting_repair = 1;
force ace_repair_engineerSetting_wheel = 0;
force ace_repair_fullRepairLocation = 0;
force ace_repair_fullRepairRequiredItems = ["ace_repair_anyToolKit"];
force ace_repair_locationsBoostTraining = false;
force ace_repair_miscRepairRequiredItems = [];
force ace_repair_miscRepairTime = 10;
force ace_repair_patchWheelEnabled = 0;
force ace_repair_patchWheelLocation = ["ground","vehicle"];
force ace_repair_patchWheelMaximumRepair = 0.3;
force ace_repair_patchWheelRequiredItems = ["ace_repair_anyToolKit"];
force ace_repair_patchWheelTime = 5;
force ace_repair_repairDamageThreshold = 0.6;
force ace_repair_repairDamageThreshold_engineer = 0.3;
force ace_repair_timeCoefficientFullRepair = 0.25;
force ace_repair_wheelChangeTime = 10;
force ace_repair_wheelRepairRequiredItems = [];

// ACE Respawn
force ace_respawn_removeDeadBodiesDisconnected = true;
force ace_respawn_savePreDeathGear = true;

// ACE Scopes
force ace_scopes_correctZeroing = true;
force ace_scopes_deduceBarometricPressureFromTerrainAltitude = false;
force ace_scopes_defaultZeroRange = 100;
force ace_scopes_enabled = false;
force ace_scopes_forceUseOfAdjustmentTurrets = false;
force ace_scopes_overwriteZeroRange = false;
force ace_scopes_simplifiedZeroing = false;
force ace_scopes_useLegacyUI = false;
force ace_scopes_zeroReferenceBarometricPressure = 1013.25;
force ace_scopes_zeroReferenceHumidity = 0;
force ace_scopes_zeroReferenceTemperature = 15;

// ACE Sitting
force acex_sitting_enable = true;

// ACE Spectator
force ace_spectator_enableAI = false;
force ace_spectator_maxFollowDistance = 5;
force ace_spectator_restrictModes = 1;
force ace_spectator_restrictVisions = 0;

// ACE Switch Units
force ace_switchunits_enableSafeZone = false;
force ace_switchunits_enableSwitchUnits = false;
force ace_switchunits_safeZoneRadius = 100;
force ace_switchunits_switchToCivilian = false;
force ace_switchunits_switchToEast = false;
force ace_switchunits_switchToIndependent = false;
force ace_switchunits_switchToWest = false;

// ACE Trenches
force ace_trenches_bigEnvelopeDigDuration = 25;
force ace_trenches_bigEnvelopeRemoveDuration = 15;
force ace_trenches_smallEnvelopeDigDuration = 20;
force ace_trenches_smallEnvelopeRemoveDuration = 12;

// ACE Uncategorized
force ace_fastroping_autoAddFRIES = false;
force ace_fastroping_requireRopeItems = false;
force ace_gunbag_swapGunbagEnabled = true;
force ace_hitreactions_minDamageToTrigger = 0.1;
ace_inventory_inventoryDisplaySize = 0;
force ace_laser_dispersionCount = 2;
force ace_laser_showLaserOnMap = 0;
force ace_marker_flags_placeAnywhere = true;
force ace_microdagr_mapDataAvailable = 2;
force ace_microdagr_waypointPrecision = 3;
force ace_noradio_enabled = true;
force ace_optionsmenu_showNewsOnMainMenu = true;
force ace_overpressure_distanceCoefficient = 1;
force ace_parachute_failureChance = 0.0518587;
force ace_parachute_hideAltimeter = false;
force ace_tagging_quickTag = 2;

// ACE User Interface
force ace_ui_allowSelectiveUI = true;
ace_ui_ammoCount = true;
ace_ui_ammoType = true;
ace_ui_commandMenu = true;
force ace_ui_enableSpeedIndicator = true;
ace_ui_firingMode = true;
ace_ui_groupBar = false;
ace_ui_gunnerAmmoCount = true;
ace_ui_gunnerAmmoType = true;
ace_ui_gunnerFiringMode = true;
ace_ui_gunnerLaunchableCount = true;
ace_ui_gunnerLaunchableName = true;
ace_ui_gunnerMagCount = true;
ace_ui_gunnerWeaponLowerInfoBackground = true;
ace_ui_gunnerWeaponName = true;
ace_ui_gunnerWeaponNameBackground = true;
ace_ui_gunnerZeroing = true;
ace_ui_hideDefaultActionIcon = false;
ace_ui_magCount = true;
ace_ui_soldierVehicleWeaponInfo = true;
ace_ui_staminaBar = true;
ace_ui_stance = true;
ace_ui_throwableCount = true;
ace_ui_throwableName = true;
ace_ui_vehicleAltitude = true;
ace_ui_vehicleCompass = true;
ace_ui_vehicleDamage = true;
ace_ui_vehicleFuelBar = true;
ace_ui_vehicleInfoBackground = true;
ace_ui_vehicleName = true;
ace_ui_vehicleNameBackground = true;
ace_ui_vehicleRadar = true;
ace_ui_vehicleSpeed = true;
ace_ui_weaponLowerInfoBackground = true;
ace_ui_weaponName = true;
ace_ui_weaponNameBackground = true;
ace_ui_zeroing = true;

// ACE Vehicle Lock
force ace_vehiclelock_defaultLockpickStrength = 10;
force ace_vehiclelock_lockVehicleInventory = false;
force ace_vehiclelock_vehicleStartingLockState = -1;

// ACE Vehicles
force ace_novehicleclanlogo_enabled = false;
ace_vehicles_hideEjectAction = false;
force ace_vehicles_keepEngineRunning = false;
ace_vehicles_speedLimiterStep = 5;
force ace_viewports_enabled = true;

// ACE View Distance Limiter
force ace_viewdistance_enabled = false;
force ace_viewdistance_limitViewDistance = 10000;
force ace_viewdistance_objectViewDistanceCoeff = 3;
force ace_viewdistance_viewDistanceAirVehicle = 0;
force ace_viewdistance_viewDistanceLandVehicle = 0;
force ace_viewdistance_viewDistanceOnFoot = 0;

// ACE View Restriction
force acex_viewrestriction_mode = 0;
force acex_viewrestriction_modeSelectiveAir = 0;
force acex_viewrestriction_modeSelectiveFoot = 0;
force acex_viewrestriction_modeSelectiveLand = 0;
force acex_viewrestriction_modeSelectiveSea = 0;
force acex_viewrestriction_preserveView = false;

// ACE Volume
force acex_volume_enabled = false;
force acex_volume_fadeDelay = 1;
force acex_volume_lowerInVehicles = true;
force acex_volume_reduction = 6;
force acex_volume_remindIfLowered = false;
force acex_volume_showNotification = true;

// ACE Weapons
force ace_common_persistentLaserEnabled = true;
force ace_reload_displayText = true;
force ace_reload_showCheckAmmoSelf = false;
ace_reloadlaunchers_displayStatusText = true;
force ace_weaponselect_displayText = true;

// ACE Weather
force ace_weather_enabled = false;
force ace_weather_showCheckAirTemperature = true;
force ace_weather_updateInterval = 300;
force ace_weather_windSimulation = true;

// ACE Wind Deflection
force ace_winddeflection_enabled = true;
force ace_winddeflection_simulationInterval = 0.05;
force ace_winddeflection_vehicleEnabled = true;

// ACE Zeus
force ace_zeus_autoAddObjects = true;
force ace_zeus_canCreateZeus = 0;
force ace_zeus_radioOrdnance = false;
force ace_zeus_remoteWind = false;
force ace_zeus_revealMines = 0;
force ace_zeus_zeusAscension = false;
force ace_zeus_zeusBird = false;

// AWR Settings
force awr_ai_enableSurrender = false;
force awr_ai_goProne = true;
force awr_ai_handgunChance = 25;
force awr_ai_incapacitationType = 0;
force awr_ai_isEnabled = false;
force awr_ai_limbHandleMode = 0;
force awr_ai_painThreshold = 0.55;
force awr_ai_playFallAnimation = true;
force awr_ai_surrenderChance = 25;
force awr_ai_surrenderChancePerEnemy = 5;
force awr_ai_surrenderDistance = 80;
force awr_ai_weaponHandleMode = 1;
force awr_main_ai_armsDamageThreshold = 1;
force awr_main_ai_bodyDamageThreshold = 1;
force awr_main_ai_legsDamageThreshold = 1;
force awr_main_bandagingMultiplier = 2;
force awr_main_damageIgnoreLevel = 0;
force awr_main_displayHints = true;
force awr_main_ignoreBurnDamage = true;
force awr_main_ignoreChanceClasses = "[]";
force awr_main_player_armsDamageThreshold = 100;
force awr_main_player_bodyDamageThreshold = 100;
force awr_main_player_legsDamageThreshold = 1;
force awr_player_concussionEnabled = false;
force awr_player_concussionTime = 5;
force awr_player_goProne = true;
force awr_player_handgunChance = 100;
force awr_player_incapacitationType = 1;
force awr_player_isEnabled = true;
force awr_player_limbHandleMode = 1;
force awr_player_painThreshold = 0.55;
force awr_player_playFallAnimation = true;
force awr_player_weaponHandleMode = 0;

// Community Base Addons
cba_diagnostic_ConsoleIndentType = -1;
force cba_diagnostic_watchInfoRefreshRate = 0.2;
force cba_disposable_dropUsedLauncher = 2;
force cba_disposable_replaceDisposableLauncher = true;
cba_events_repetitionMode = 1;
force cba_network_loadoutValidation = 2;
cba_optics_usePipOptics = false;
cba_ui_notifyLifetime = 4;
cba_ui_StorePasswords = 1;

// Crows Zeus Additions
crowsza_pingbox_CBA_Setting_enabled = true;
crowsza_pingbox_CBA_Setting_fade_duration = 300;
crowsza_pingbox_CBA_Setting_fade_enabled = true;
crowsza_pingbox_CBA_Setting_oldLimit = 600;
force crowsza_zeus_text_CBA_Setting_rc_helper = true;
force crowsza_zeus_text_CBA_Setting_rc_helper_color = [1,1,1,1];
force crowsza_zeus_text_CBA_Setting_surrender_helper = true;
force crowsza_zeus_text_CBA_Setting_surrender_helper_color = [1,1,1,1];
force crowsza_zeus_text_CBA_Setting_zeusTextLine1 = true;
force crowsza_zeus_text_CBA_Setting_zeusTextLine2 = true;
force crowsza_zeus_text_CBA_Setting_zeusTextLine3 = true;

// Diwako Stalker Like Anomalies
force ANOMALY_DEBUG = false;
force ANOMALY_DETECTION_RANGE = 20;
force ANOMALY_DETECTOR_ITEM = "AnomalyDetector";
force ANOMALY_GAS_MASKS = "GP5_RaspiratorPS,GP5Filter_RaspiratorPS,GP7_RaspiratorPS,GP21_GasmaskPS,SE_S10,G_Respirator_white_F,MASK_M40_OD,MASK_M40,MASK_M50";
force ANOMALY_IDLE_DISTANCE = 350;
force ANOMALY_TRIGGER_DISTANCE = 300;
force diwako_anomalies_enable = true;

// GRAD Trenches
force grad_trenches_functions_allowBigEnvelope = true;
force grad_trenches_functions_allowCamouflage = true;
force grad_trenches_functions_allowDigging = true;
force grad_trenches_functions_allowEffects = true;
force grad_trenches_functions_allowGiantEnvelope = true;
force grad_trenches_functions_allowHitDecay = true;
force grad_trenches_functions_allowLongEnvelope = true;
force grad_trenches_functions_allowShortEnvelope = true;
force grad_trenches_functions_allowSmallEnvelope = true;
force grad_trenches_functions_allowTextureLock = true;
force grad_trenches_functions_allowTrenchDecay = false;
force grad_trenches_functions_allowVehicleEnvelope = true;
force grad_trenches_functions_bigEnvelopeDamageMultiplier = 2;
force grad_trenches_functions_bigEnvelopeDigTime = 40;
force grad_trenches_functions_bigEnvelopeRemovalTime = -1;
force grad_trenches_functions_buildFatigueFactor = 1;
force grad_trenches_functions_camouflageRequireEntrenchmentTool = true;
force grad_trenches_functions_createTrenchMarker = false;
force grad_trenches_functions_decayTime = 1800;
force grad_trenches_functions_giantEnvelopeDamageMultiplier = 1;
force grad_trenches_functions_giantEnvelopeDigTime = 90;
force grad_trenches_functions_giantEnvelopeRemovalTime = -1;
force grad_trenches_functions_hitDecayMultiplier = 1;
force grad_trenches_functions_LongEnvelopeDigTime = 100;
force grad_trenches_functions_LongEnvelopeRemovalTime = -1;
force grad_trenches_functions_playersInAreaRadius = 0;
force grad_trenches_functions_shortEnvelopeDamageMultiplier = 2;
force grad_trenches_functions_shortEnvelopeDigTime = 15;
force grad_trenches_functions_shortEnvelopeRemovalTime = -1;
force grad_trenches_functions_smallEnvelopeDamageMultiplier = 3;
force grad_trenches_functions_smallEnvelopeDigTime = 30;
force grad_trenches_functions_smallEnvelopeRemovalTime = -1;
force grad_trenches_functions_stopBuildingAtFatigueMax = false;
force grad_trenches_functions_textureLockDistance = 5;
force grad_trenches_functions_timeoutToDecay = 7200;
force grad_trenches_functions_vehicleEnvelopeDamageMultiplier = 1;
force grad_trenches_functions_vehicleEnvelopeDigTime = 120;
force grad_trenches_functions_vehicleEnvelopeRemovalTime = -1;
force grad_trenches_functions_vehicleTrenchBuildSpeed = 5;

// Improved Melee System (Client Settings)
IMS_CustomCamer_Y = 3;
IMS_CustomCameraUsedByUserAllowed = true;
IMS_EnablePlayerSounds = false;
IMS_HudCoordinate_X = 0.01;
IMS_HudCoordinate_Y = 0.9;
IMS_ShowHealthHud = true;

// Improved Melee System (Server Settings)
force IMS_AddKnifeToUnit = false;
force IMS_BayonetDistance = "10";
force IMS_BayonetOnAI = false;
force IMS_BluntWeapon = true;
force IMS_CustomAIHEALTH = "2";
force IMS_DamageMultiplierParam = "1";
force IMS_DamageMultiplierParamPlayer = "0.5";
force IMS_ExecutionChanceParametr = "40";
force IMS_isFistsAllowd = true;
force IMS_isHumansCanHitSM = false;
force IMS_isImsCanHitAllies = true;
force IMS_isKickButtInstaKill = false;
force IMS_isStaticDeaths = false;
force IMS_RifleDodgeSet = true;
force IMS_StealthAI_Ears = 15;
force IMS_StealthAI_Eyes = 40;
force IMS_WBK_CUSTOMCAMSERVER = false;
force IMS_WBK_MAINFPTP = true;

// JLTS - Debug
force JLTS_settings_Debug_chat = true;
force JLTS_settings_Debug_mainSwitch = 0;
force JLTS_settings_Debug_rpt = true;

// JLTS - Special equipment
force JLTS_settings_jumppack_customConsumption = false;
force JLTS_settings_jumppack_customConsumptionCoef = 1;
force JLTS_settings_jumppack_mainSwitch = 0;
JLTS_settings_jumppack_profileDescentCoef = 0.3;
JLTS_settings_jumppack_profileDescentRatio = "1,1";
JLTS_settings_jumppack_profileHighCoef = 1;
JLTS_settings_jumppack_profileHighRatio = "1,2";
JLTS_settings_jumppack_profileLongCoef = 1;
JLTS_settings_jumppack_profileLongRatio = "2,1";
JLTS_settings_jumppack_profileStandardCoef = 1;
JLTS_settings_jumppack_profileStandardRatio = "1,1";
force JLTS_settings_jumppack_stances = 1;

// JLTS - Weapons
force JLTS_settings_Common_dropShield = true;
force JLTS_settings_EMP_EMPEffectScope = 0;
force JLTS_settings_EMP_mainSwitch = 1;
force JLTS_settings_EMP_notifyPlayer = true;
force JLTS_settings_EMP_repairTimeHandgun = 20;
force JLTS_settings_EMP_repairTimePrimary = 30;
force JLTS_settings_EMP_repairTimeSecondary = 40;
force JLTS_settings_Stun_mainSwitch = 1;
force JLTS_settings_Stun_worksInVehicles = false;

// LAMBS Danger
force lambs_danger_cqbRange = 60;
force lambs_danger_disableAIAutonomousManoeuvres = false;
force lambs_danger_disableAIDeployStaticWeapons = false;
force lambs_danger_disableAIFindStaticWeapons = false;
force lambs_danger_disableAIHideFromTanksAndAircraft = true;
force lambs_danger_disableAIPlayerGroup = false;
force lambs_danger_disableAIPlayerGroupReaction = false;
force lambs_danger_disableAutonomousFlares = false;
force lambs_danger_disableAutonomousSmokeGrenades = false;
force lambs_danger_panicChance = 0;

// LAMBS Danger Eventhandlers
force lambs_eventhandlers_ExplosionEventHandlerEnabled = true;
force lambs_eventhandlers_ExplosionReactionTime = 9;

// LAMBS Danger WP
force lambs_wp_autoAddArtillery = true;

// LAMBS Main
force lambs_main_combatShareRange = 200;
force lambs_main_debug_drawAllUnitsInVehicles = false;
force lambs_main_debug_Drawing = false;
force lambs_main_debug_FSM = false;
force lambs_main_debug_FSM_civ = false;
force lambs_main_debug_functions = false;
force lambs_main_debug_RenderExpectedDestination = false;
force lambs_main_disableAICallouts = false;
force lambs_main_disableAIDodge = false;
force lambs_main_disableAIFleeing = true;
force lambs_main_disableAIGestures = false;
force lambs_main_disableAutonomousMunitionSwitching = false;
force lambs_main_disablePlayerGroupSuppression = false;
force lambs_main_indoorMove = 0.20405;
force lambs_main_maxRevealValue = 1;
force lambs_main_minFriendlySuppressionDistance = 5;
force lambs_main_minObstacleProximity = 5;
force lambs_main_minSuppressionRange = 50;
force lambs_main_radioBackpack = 2000;
force lambs_main_radioDisabled = false;
force lambs_main_radioEast = 500;
force lambs_main_radioGuer = 500;
force lambs_main_radioShout = 100;
force lambs_main_radioWest = 500;

// Legion Studios
ls_setting_impulseHintDisplay = 2;

// Lightsaber's And Force
force IMS_ForceKillFriendlies = false;
force IMS_LightSabers_GlobalDamageKnight = "25";
force IMS_LightSabers_GlobalDamageMaster = "50";
force IMS_LightSabers_GlobalDamagePadawan = "25";
force IMS_LightSabers_Mana_Knight = "0.001";
force IMS_LightSabers_Mana_Master = "0.001";
force IMS_LightSabers_Mana_Padawan = "0.001";

// LRG AI
force LRG_AI_AimingAccuracy = 0.1;
force LRG_AI_AimingShake = 0.45;
force LRG_AI_AimingSpeed = 0.3;
force LRG_AI_CivCourage = 1;
force LRG_AI_CivFleeing = false;
force LRG_AI_Commanding = 1;
force LRG_AI_Courage = 1;
force LRG_AI_DynSim = false;
force LRG_AI_General = 1;
force LRG_AI_InitialAI = false;
force LRG_AI_ReloadSpeed = 0.5;
force LRG_AI_Reporting = false;
force LRG_AI_SpotDistance = 0.4;
force LRG_AI_SpotTime = 0.2;

// LRG AIS Revive
force LRG_AIS_ACTION_DISTANCE = 6;
force LRG_AIS_AI_HELP_RADIUS = 100;
force LRG_AIS_BLEEDOUT_MULTIPLIER = 1;
force LRG_AIS_BLEEDOUT_TIME = 400;
force LRG_AIS_CONSUME_FAKS = true;
force LRG_AIS_DAMAGE_TOLLERANCE_FACTOR = 1;
force LRG_AIS_DISABLE_RESPAWN_BUTTON = 30;
force LRG_AIS_IMPACT_EFFECTS = false;
force LRG_AIS_MASTER_ENABLE = false;
force LRG_AIS_MEDICAL_EDUCATION = 2;
force LRG_AIS_NO_CHAT = false;
force LRG_AIS_REQUIRE_MEDIKIT = true;
force LRG_AIS_RESTORE_LOADOUT = true;
force LRG_AIS_REVIVE_GUARANTY = false;
force LRG_AIS_REVIVE_HEAL = true;
force LRG_AIS_REVIVE_INIT_UNITS = 0;
force LRG_AIS_REVIVETIME = 20;
force LRG_AIS_SHOW_COUNTDOWN = false;
force LRG_AIS_SHOW_DIARYINFO = false;
force LRG_AIS_SHOW_UNC_3D_MARKERS = false;
force LRG_AIS_SHOW_UNC_MARKERS = false;
force LRG_AIS_SHOW_UNC_MESSAGE_TO = 0;
force LRG_AIS_STABILIZETIME = 15;
force LRG_AIS_TOGGLE_RADIO = false;

// LRG Channels
force LRG_Channels_CommandDuration = 0;
force LRG_Channels_CommandText = false;
force LRG_Channels_CommandVoice = false;
force LRG_Channels_DirectDuration = 0;
force LRG_Channels_DirectText = true;
force LRG_Channels_DirectVoice = false;
force LRG_Channels_GlobalDuration = 0;
force LRG_Channels_GlobalText = false;
force LRG_Channels_GlobalVoice = false;
force LRG_Channels_GroupDuration = 0;
force LRG_Channels_GroupText = true;
force LRG_Channels_GroupVoice = false;
force LRG_Channels_SideDuration = 60;
force LRG_Channels_SideText = true;
force LRG_Channels_SideVoice = false;
force LRG_Channels_VehicleDuration = 0;
force LRG_Channels_VehicleText = false;
force LRG_Channels_VehicleVoice = false;

// LRG Civilians
force LRG_Civilians_enableFollowGestures = true;
force LRG_Civilians_enableGestures = true;
force LRG_Civilians_enableGetDownGestures = true;
force LRG_Civilians_enableGoAwayGestures = true;
force LRG_Civilians_enableGreetingGestures = true;
force LRG_Civilians_enableStopGestures = true;
force LRG_Civilians_successChance_armed = 0.5;
force LRG_Civilians_successChance_unarmed = 0.8;

// LRG Creator Actions
force LRG_CreatorActions_Channels = true;
force LRG_CreatorActions_EndMission = true;
force LRG_CreatorActions_Master = true;

// LRG Logistics
force LRG_Logistics_axeMaxTime = 40;
force LRG_Logistics_axeTimeFactor = 1;

// LRG Main
force LRG_Main_ArsenalSaveLoad = true;
force LRG_Main_CHViewDistance = true;
force LRG_Main_CueCards = true;
force LRG_Main_Diary = false;
force LRG_Main_DynamicGroups = false;
force LRG_Main_DynamicSim = false;
force LRG_Main_Earplugs = false;
force LRG_Main_FatigueVanilla = false;
force LRG_Main_FlipVehicle = true;
force LRG_Main_FPSCounter = true;
force LRG_Main_LockCamVehicle = false;
force LRG_Main_Logging = false;
force LRG_Main_MapIcons = true;
force LRG_Main_MaydayAccess = 2;
force LRG_Main_PilotCheck = true;
force LRG_Main_QSMagRepack = false;
force LRG_Main_TFARTerrainInterference = 1;
force LRG_Main_TFARTransmitRange = 2.5;
force LRG_Main_VehicleCrewList = true;
force LRG_Main_ViewDistanceMaxDistance = 10000;
force LRG_Main_ViewDistanceMaxObjectDistance = 10000;
force LRG_Main_ViewDistanceNoGrass = false;
force LRG_Main_VoyagerCompass = false;

// LRG QS Icons
force LRG_QS_ST_AINames = false;
force LRG_QS_ST_colorInjured = [0.75,0.55,0,0.75];
force LRG_QS_ST_enableGroupIcons = true;
force LRG_QS_ST_gps_enableUnitIcons = true;
force LRG_QS_ST_GPSDist = 300;
force LRG_QS_ST_GPSshowGroupOnly = false;
force LRG_QS_ST_GPSshowNames = false;
force LRG_QS_ST_groupTextFactionOnly = true;
force LRG_QS_ST_iconColor_CIVILIAN = [0.4,0,0.5,0.65];
force LRG_QS_ST_iconColor_EAST = [0.5,0,0,0.65];
force LRG_QS_ST_iconColor_RESISTANCE = [0,0.5,0,0.65];
force LRG_QS_ST_iconColor_UNKNOWN = [0.7,0.6,0,0.5];
force LRG_QS_ST_iconColor_WEST = [0,0.3,0.6,0.65];
force LRG_QS_ST_iconMapText = false;
force LRG_QS_ST_iconTextFonts = 5;
force LRG_QS_ST_iconUpdatePulseDelay = 30;
force LRG_QS_ST_map_enableUnitIcons = true;
force LRG_QS_ST_MasterEnable = false;
force LRG_QS_ST_MedicalIconColor = [1,0.41,0,1];
force LRG_QS_ST_MedicalSystem = 3;
force LRG_QS_ST_showAI = false;
force LRG_QS_ST_showAIGroups = false;
force LRG_QS_ST_showAINames = false;
force LRG_QS_ST_showCivilianIcons = false;
force LRG_QS_ST_showFactionOnly = true;
force LRG_QS_ST_showGroupHudIcons = false;
force LRG_QS_ST_showGroupMapIcons = true;
force LRG_QS_ST_showGroupOnly = true;
force LRG_QS_ST_showMedicalWounded = false;
force LRG_QS_ST_showMOS = false;
force LRG_QS_ST_showMOS_range = 3500;
force LRG_QS_ST_showOwnGroup = false;

// LRG Weather
force LRG_Weather_DayTimeAcc = 1;
force LRG_Weather_Master = false;
force LRG_Weather_MaxTime = 60;
force LRG_Weather_MinTime = 1;
force LRG_Weather_NightTimeAcc = 1;
force LRG_Weather_RealTime = true;
force LRG_Weather_StartWeather = 1;
force LRG_Weather_SyncTime = 60;

// LRG Zeus
force LRG_Zeus_Module_AISpawnsEast = true;
force LRG_Zeus_Module_AISpawnsIndep = true;
force LRG_Zeus_Module_AISpawnsWest = true;
force LRG_Zeus_Module_CivilianSpawns = true;
force LRG_Zeus_Module_MedicalDummy = true;
force LRG_Zeus_Module_SafeZone = true;

// MokTech Industries - Admin Messages
force mti_admin_messages_enable = true;

// MokTech Industries - Aircraft
force mti_aircraft_cmColoursEnabled = true;
force mti_aircraft_laatc_loadDistance = 25;
force mti_aircraft_laatc_loadSpeed = 15;
force mti_aircraft_requirePilot = true;
force mti_aircraft_serviceTime_long = 60;
force mti_aircraft_serviceTime_short = 20;

// MokTech Industries - Backpack on Chest
force mti_boc_disabled = false;

// MokTech Industries - catTab (UI)
mti_catTab_ui_androidDesktopBackgroundMode = 0;
mti_catTab_ui_androidDesktopBackgroundPreset = "\z\mti\addons\catTab_data\img\ui\desktop\classic\android_desktop_background_0_co.paa";
mti_catTab_ui_androidDesktopColor = [0.239,0.863,0.517];
mti_catTab_ui_androidDesktopCustomImageName = "android_desktop_background_co.jpg";
force mti_catTab_ui_enableCustomBackground = true;
mti_catTab_ui_tabletDesktopBackgroundMode = 0;
mti_catTab_ui_tabletDesktopBackgroundPreset = "\z\mti\addons\catTab_data\img\ui\desktop\classic\tablet_desktop_background_0_co.paa";
mti_catTab_ui_tabletDesktopColor = [0,0.443,0.348];
mti_catTab_ui_tabletDesktopCustomImageName = "tablet_desktop_background_co.jpg";

// MokTech Industries - CIS
force mti_factions_cis_b2_health = 120;
force mti_factions_cis_deka_defaultShieldHealth = 750;
force mti_factions_cis_deka_shieldCooldown = 80;
force mti_factions_cis_deka_shieldTimeout = 60;
force mti_factions_cis_dispenser_coolDown = 60;

// MokTech Industries - Common
force mti_common_enableLogging = true;
force mti_common_respawnUpdateEnabled = true;
force mti_common_stanceChangeEnabled = true;
force mti_common_teleporterDuration = 2;
force mti_common_wsway_adjust = 0.9;
force mti_common_wsway_enabled = true;

// MokTech Industries - CuffBreak
force mti_cuffbreak_ai_enabled = true;
force mti_cuffbreak_defaultAIEscapeStrength = 12;
force mti_cuffbreak_enabled = true;

// MokTech Industries - Doors
force mti_doors_axe_time_coefficient = 1.25;
force mti_doors_buttkick_default_strength = 4;
force mti_doors_default_lockstrength = 20;
force mti_doors_kick_default_strength = 20;
force mti_doors_lockpick_fast_breakChance = 0.75;
force mti_doors_lockpick_fast_coefficient = 0.5;
force mti_doors_lockpick_fast_failChance = 0.25;
force mti_doors_lockpick_slow_breakChance = 0.25;
force mti_doors_lockpick_slow_failChance = 0.05;

// MokTech Industries - Equipment
force mti_equipment_flagsEnabled = true;
force mti_equipment_knifeEnabled = false;
mti_equipment_nvg_customBrightness = 0;
mti_equipment_nvg_customColour = [0.750812,0.750812,0.745176];
mti_equipment_nvg_customContrast = 4.23882;
mti_equipment_nvg_customEnabled = true;
mti_equipment_nvg_customWhiteP = false;

// MokTech Industries - Explosives
force mti_explosives_advSetup_requireDemo = true;
force mti_explosives_DP3_destroyAttached = true;
force mti_explosives_magneticModeEnabled = true;

// MokTech Industries - Field Defibrillator
force mti_medical_defib_arrest_chance = 0.1;
force mti_medical_defib_success_chance = 0.8;

// MokTech Industries - Fortify
force mti_fortify_allowSaving = true;
force mti_fortify_fortifyAllowed = true;
force mti_fortify_markObjectsOnMap = 1;
force mti_fortify_recallTimeCoef = 0.25;
force mti_fortify_timeCostCoefficient = 0.25;
force mti_fortify_timeMax = 30;
force mti_fortify_timeMin = 1.5;

// MokTech Industries - Hunger Games
force mti_hungergames_enabled = true;

// MokTech Industries - Intercom
force mti_intercom_maxRange = 100;
force mti_intercom_systemEnabled = true;

// MokTech Industries - Katarn_OS
force mti_katarnOS_intercom_enabled = true;
force mti_katarnOS_lowLight_enabled = true;
force mti_katarnOS_repulsorAngle = 90;
force mti_katarnOS_repulsorRange = 10;
force mti_katarnOS_shield_duration = 210;
force mti_katarnOS_shield_maxCharges = 3;

// MokTech Industries - Logistics
force mti_logistics_spawnCooldown = 45;
force mti_logistics_spawnDuration = 25;

// MokTech Industries - Logistics (Cratefiller)
force mti_logistics_cratefiller_param_cratefillerOverview = true;
force mti_logistics_cratefiller_param_inventoryBlacklist = "[]";
force mti_logistics_cratefiller_param_spawnAndDelete = true;
force mti_logistics_cratefiller_param_usageRadius = 25;

// MokTech Industries - Medical
force mti_medical_bactaPatch_timeMod = 1.25;
force mti_medical_bactaSpray_timeMod = 0.5;
force mti_medical_bodybagDisposalEnabled = true;
force mti_medical_enableDiary = true;
force mti_medical_locationMedisensor = 0;
force mti_medical_medicRequired_Bandages = 1;
force mti_medical_medicRequired_batroxobine = 1;
force mti_medical_medicRequired_deraformine = 1;
force mti_medical_medicRequired_glitteryl = 1;
force mti_medical_medicRequired_latheniol = 1;
force mti_medical_medicRequired_Medisensor = 1;
force mti_medical_medicRequired_nevastrin8 = 2;
force mti_medical_medicRequired_pba = 1;
force mti_medical_medicRequired_reorient = 1;
force mti_medical_medicRequired_symoxin = 0;
force mti_medical_medicRequired_vutalamine = 1;
force mti_medical_nevastrin8_maxCount = 5;
force mti_medical_pba_cpr_boost = 5;
force mti_medical_pba_od_enabled = true;
force mti_medical_pba_od_time = 90;
force mti_medical_pba_pain_boost = 10;
force mti_medical_pba_speed_boost = 1.2;
force mti_medical_pba_sway_boost = 1.15;
force mti_medical_showBloodLevel = true;
force mti_medical_systemEnabled = true;
force mti_medical_timeMedisensor = 10;
force mti_medical_vutalamine_speed_reduction = 0.8;
force mti_medical_vutalamine_sway_reduction = 0.75;

// MokTech Industries - Pangolin
force mti_pangolin_baseShieldRegen = 2;
force mti_pangolin_baseShieldStrength = 100;
force mti_pangolin_cqcShieldRegenBoost = 1.5;
force mti_pangolin_cqcShieldTimeoutMod = 0.5;
mti_pangolin_disableBreachVoice = false;
force mti_pangolin_enabled = true;
force mti_pangolin_medicShieldBoost = 1.25;
force mti_pangolin_regenTimeoutBreach = 15;
force mti_pangolin_regenTimeoutHit = 7;

// MokTech Industries - Tech
force mti_tech_droidhack_firewalls = 3;
force mti_tech_droidwave_firewalls = 2;
force mti_tech_firewall_prompts = 3;
force mti_tech_hackdance_firewalls = 20;
force mti_tech_hackfear_firewalls = 2;
force mti_tech_hackintel_firewalls = 1;
force mti_tech_hackmines_firewalls = 1;
force mti_tech_hackpacify_firewalls = 2;
force mti_tech_hackremote_firewalls = 3;

// MokTech Industries - Weapons
force mti_weapons_core_acid_duration = 300;
force mti_weapons_core_airburstEnabledSettings = true;
force mti_weapons_core_ion_charge_max = 5;
force mti_weapons_core_ion_duration = 10;
force mti_weapons_core_stun_charge_max = 5;
force mti_weapons_core_stun_duration = 10;
force mti_weapons_core_tracking_duration = 900;
force mti_weapons_core_tracking_enabled = true;
force mti_weapons_core_tracking_scanDelay = 5;

// MokTech Industries - Zeus
force mti_zeus_ZEN_useTraits = true;

// OPTRE Powered MJOLNIR
OPTRE_HUD_ENEMY_COLOR = [1,0.2,0.2,1];
OPTRE_HUD_FRIENDLY_COLOR = [0.7,1,1,1];
OPTRE_HUD_GROUP_COLOR = [1,1,1,1];
OPTRE_HUD_HUMAN_ICON = "\OPTRE_Suit_Scripts\textures\OPTRE_MJOLNIR_hudTargetInfantry.paa";
OPTRE_HUD_HUMAN_SIZE = 0.3;
OPTRE_HUD_NEUTRAL_COLOR = [1,1,0,1];
OPTRE_HUD_STATIC_ICON = "\OPTRE_Suit_Scripts\textures\OPTRE_MJOLNIR_hudTargetEmplacement.paa";
OPTRE_HUD_STATIC_SIZE = 0.4;
OPTRE_HUD_VEHICLE_ICON = "\OPTRE_Suit_Scripts\textures\OPTRE_MJOLNIR_hudTargetVehicle.paa";
OPTRE_HUD_VEHICLE_SIZE = 0.6;
force OPTRE_JUMP_SUITS_SETTING = "";
force OPTRE_MJOLNIR_ACTIVATE_AI = true;
OPTRE_MJOLNIR_ALLOW_LOWLIGHT_SETTING = true;
OPTRE_MJOLNIR_ALLOW_TARGETING_SETTING = true;
OPTRE_MJOLNIR_BOOTUP_COLOR = [0.694,0.933,0.345,1];
force OPTRE_MJOLNIR_CAMSHAKE = false;
OPTRE_MJOLNIR_CHARGE_EFFECT_COLOR = [0.8,1,1,0.2];
OPTRE_MJOLNIR_CHARGE_TEXTURE_COLOR = [0.8,1,1,1];
OPTRE_MJOLNIR_DEPLETED_ALERT_COLOR = [1,0.2,0.2,0.8];
OPTRE_MJOLNIR_DEPLETED_EFFECT_COLOR = [1,0.2,0.2,1];
force OPTRE_MJOLNIR_ENABLE_JUMP = false;
force OPTRE_MJOLNIR_ENABLE_SPARKS_HIT = true;
force OPTRE_MJOLNIR_ENABLE_SPARKS_SHIELD = true;
force OPTRE_MJOLNIR_ENERGY_BAR_ACTIVE = false;
OPTRE_MJOLNIR_ENERGY_BAR_COLOR = [0.5,0.9,0.9,0.8];
OPTRE_MJOLNIR_ENERGY_BAR_TEXT_COLOR = [0.7,1,1,0.8];
OPTRE_MJOLNIR_HITEFFECT_COLOR = [1,1,0.2,1];
OPTRE_MJOLNIR_HITEFFECT_DEPLETED_COLOR = [1,0.2,0.2,1];
force OPTRE_MJOLNIR_HUD_ACTIVE_INTRO = false;
force OPTRE_MJOLNIR_INCREASED_SPEED = false;
OPTRE_MJOLNIR_INFODISPLAY_COLOR = [0.7,1,1,0.8];
OPTRE_MJOLNIR_INFOTEXT_COLOR = [0.7,1,1,0.8];
force OPTRE_MJOLNIR_JUMP_FORWARD = 3;
force OPTRE_MJOLNIR_JUMP_UP_HIGH = 3;
force OPTRE_MJOLNIR_JUMP_UP_LOW = 5;
OPTRE_MJOLNIR_OVERLAY_COLOR = [0.7,1,1,0.4];
OPTRE_MJOLNIR_OVERWRITE_CONFIG_SHIELD = false;
force OPTRE_MJOLNIR_PREVENT_FALLDAMAGE = false;
OPTRE_MJOLNIR_RADAR_COLOR = [0.7,1,1,0.8];
force OPTRE_MJOLNIR_RECOIL_MODIFIER = 0.3;
OPTRE_MJOLNIR_SHIELD_DELAY = 0.1;
force OPTRE_MJOLNIR_SHIELD_ENERGY = 50;
force OPTRE_MJOLNIR_SHIELD_ENERGY_AI = 100;
force OPTRE_MJOLNIR_SHIELD_MODIFIER_1 = 1;
force OPTRE_MJOLNIR_SHIELD_MODIFIER_2 = 1.5;
force OPTRE_MJOLNIR_SHIELD_MODIFIER_3 = 2;
force OPTRE_MJOLNIR_SHIELD_MODIFIER_4 = 2.5;
force OPTRE_MJOLNIR_SHIELD_MODIFIER_5 = 3;
force OPTRE_MJOLNIR_SHIELD_MODIFIER_SUITS_1 = "";
force OPTRE_MJOLNIR_SHIELD_MODIFIER_SUITS_2 = "";
force OPTRE_MJOLNIR_SHIELD_MODIFIER_SUITS_3 = "";
force OPTRE_MJOLNIR_SHIELD_MODIFIER_SUITS_4 = "";
force OPTRE_MJOLNIR_SHIELD_MODIFIER_SUITS_5 = "";
force OPTRE_MJOLNIR_SHIELD_REGEN = 0.8;
force OPTRE_MJOLNIR_SHIELD_REGEN_AI = 1;
force OPTRE_MJOLNIR_SHOW_ACTIVATE = false;
force OPTRE_MJOLNIR_SHOW_DEACTIVATE = false;
OPTRE_MJOLNIR_SHOW_OUTLINE = true;
OPTRE_MJOLNIR_SHOW_OVERLAY = true;
force OPTRE_MJOLNIR_SPEED_MODIFIER = 1;
force OPTRE_MJOLNIR_SUPPRESS_RECOIL = false;
OPTRE_MJOLNIR_TARGETING_INTERVAL_RANGE_SETTING = 100;
OPTRE_MJOLNIR_TARGETING_MAX_RANGE_SETTING = 1000;
OPTRE_MJOLNIR_TARGETING_MIN_RANGE_SETTING = 100;
OPTRE_MJOLNIR_WEAPON_ICON_COLOR = [0.7,1,1,0.8];
OPTRE_POWERED_HELMETS = "OPTRE_MJOLNIR_Mk4Helmet,OPTRE_MJOLNIR_Mk4Helmet_Blue,OPTRE_MJOLNIR_Mk4Helmet_Red,OPTRE_FC_MJOLNIR_MKV_Helmet,OPTRE_FC_MJOLNIR_MKV_Helmet_Black,OPTRE_FC_MJOLNIR_MKV_Helmet_117,OPTRE_FC_MJOLNIR_MKV_Helmet_Caboose,OPTRE_FC_MJOLNIR_MKV_Helmet_Freeman,OPTRE_FC_MJOLNIR_MKV_Helmet_Church,OPTRE_FC_MJOLNIR_MKV_Helmet_Donut,OPTRE_FC_MJOLNIR_MKV_Helmet_Simmons,OPTRE_FC_MJOLNIR_MKV_Helmet_Night,OPTRE_FC_MJOLNIR_MKV_Helmet_Olive,OPTRE_FC_MJOLNIR_MKV_Helmet_Grif,OPTRE_FC_MJOLNIR_MKV_Helmet_Sarge,OPTRE_FC_MJOLNIR_MKV_Helmet_Tucker,OPTRE_MJOLNIR_MkVBHelmet,OPTRE_MJOLNIR_MkVBHelmet_UA,OPTRE_MJOLNIR_MkVBHelmet_UA_HUL,OPTRE_MJOLNIR_MkVBHelmet_Red,OPTRE_MJOLNIR_MkVBHelmet_Blue,OPTRE_MJOLNIR_MkVBHelmet_Black,OPTRE_MJOLNIR_Commando,OPTRE_MJOLNIR_Commando_HUL3,OPTRE_MJOLNIR_Commando_DefaultV_HUL3,OPTRE_MJOLNIR_Commando_SilverV_HUL3,OPTRE_MJOLNIR_Commando_BlueV_HUL3,OPTRE_MJOLNIR_Commando_BlackV_HUL3,OPTRE_MJOLNIR_Commando_Black_HUL3,OPTRE_MJOLNIR_Commando_Black_DefaultV_HUL3,OPTRE_MJOLNIR_Commando_Black_SilverV_HUL3,OPTRE_MJOLNIR_Commando_Black_BlueV_HUL3,OPTRE_MJOLNIR_Commando_Black_BlackV_HUL3,OPTRE_MJOLNIR_Commando_Blue_HUL3,OPTRE_MJOLNIR_Commando_Blue_DefaultV_HUL3,OPTRE_MJOLNIR_Commando_Blue_SilverV_HUL3,OPTRE_MJOLNIR_Commando_Blue_BlueV_HUL3,OPTRE_MJOLNIR_Commando_Blue_BlackV_HUL3,OPTRE_MJOLNIR_Commando_Red_HUL3,OPTRE_MJOLNIR_Commando_Red_DefaultV_HUL3,OPTRE_MJOLNIR_Commando_Red_SilverV_HUL3,OPTRE_MJOLNIR_Commando_Red_BlueV_HUL3,OPTRE_MJOLNIR_Commando_Red_BlackV_HUL3,OPTRE_MJOLNIR_MkVBHelmet_BLKV,OPTRE_MJOLNIR_MkVBHelmet_BLUV,OPTRE_MJOLNIR_MkVBHelmet_SLVV,OPTRE_MJOLNIR_MkVBHelmet_Black_SLVV,OPTRE_MJOLNIR_Commando_DefaultV,OPTRE_MJOLNIR_Commando_SilverV,OPTRE_MJOLNIR_Commando_BlueV,OPTRE_MJOLNIR_Commando_BlackV,OPTRE_MJOLNIR_Commando_Black,OPTRE_MJOLNIR_Commando_Black_DefaultV,OPTRE_MJOLNIR_Commando_Black_SilverV,OPTRE_MJOLNIR_Commando_Black_BlueV,OPTRE_MJOLNIR_Commando_Black_BlackV,OPTRE_MJOLNIR_Commando_Blue,OPTRE_MJOLNIR_Commando_Blue_DefaultV,OPTRE_MJOLNIR_Commando_Blue_SilverV,OPTRE_MJOLNIR_Commando_Blue_BlueV,OPTRE_MJOLNIR_Commando_Blue_BlackV,OPTRE_MJOLNIR_Commando_Red,OPTRE_MJOLNIR_Commando_Red_DefaultV,OPTRE_MJOLNIR_Commando_Red_SilverV,OPTRE_MJOLNIR_Commando_Red_BlueV,OPTRE_MJOLNIR_Commando_Red_BlackV,OPTRE_MJOLNIR_CQB,OPTRE_MJOLNIR_CQC,OPTRE_MJOLNIR_Pilot,OPTRE_MJOLNIR_Operator,OPTRE_MJOLNIR_EOD,OPTRE_MJOLNIR_ODST,OPTRE_FC_MJOLNIR_Mark_VI_Helmet,OPTRE_FC_MJOLNIR_Mark_VI_Helmet_White,OPTRE_FC_MJOLNIR_Mark_VI_Helmet_Olive,OPTRE_FC_MJOLNIR_Mark_VI_Helmet_Tan,OPTRE_FC_MJOLNIR_Mark_VI_Helmet_Tex,OPTRE_FC_MJOLNIR_Mark_VI_Helmet_Caboose,OPTRE_FC_MJOLNIR_Mark_VI_Helmet_Church,OPTRE_FC_MJOLNIR_Mark_VI_Helmet_Donut,OPTRE_FC_MJOLNIR_Mark_VI_Helmet_Grif,OPTRE_FC_MJOLNIR_Mark_VI_Helmet_Simmons,OPTRE_FC_MJOLNIR_Mark_VI_Helmet_Sarge,OPTRE_FC_MJOLNIR_Mark_VI_Helmet_Kaikaina,OPTRE_FC_MJOLNIR_Mark_VI_Helmet_Lopez,OPTRE_FC_MJOLNIR_Mark_VI_Helmet_Doc,OPTRE_FC_MJOLNIR_Mark_VI_Helmet_North,OPTRE_FC_MJOLNIR_Mark_VI_Helmet_South,OPTRE_FC_MJOLNIR_Mark_VI_Helmet_York,OPTRE_FC_MJOLNIR_Mark_VI_Helmet_Washington,OPTRE_FC_MJOLNIR_Mark_VI_Helmet_Tucker,OPTRE_MJOLNIR_EVAHelmet,OPTRE_MJOLNIR_EVAHelmet_Emily,OPTRE_MJOLNIR_MPHelmet,OPTRE_MJOLNIR_ReconHelmet,OPTRE_FC_Elite_Helmet_FieldMarshal,OPTRE_FC_Elite_Helmet_HonorGuard_Ultra,OPTRE_FC_Elite_Helmet_HonorGuard,OPTRE_FC_Elite_Helmet_Major,OPTRE_FC_Elite_Helmet_Officer,OPTRE_FC_Elite_Helmet_Minor,OPTRE_FC_Elite_Helmet_SpecOps,OPTRE_FC_Elite_Helmet_Ultra,OPTRE_FC_Elite_Helmet_Zealot";
force OPTRE_POWERED_SUITS_SETTING = "";
OPTRE_START_ON_INIT = true;

// OPTRE Settings
OPTRE_AircraftHUD_colour = [0.082,0.408,0.039,1];
OPTRE_Debug_Mode = false;
force OPTRE_Enable_Humans_To_Detach = false;
force OPTRE_Enable_Supercombustion_dev = true;
force OPTRE_Enable_Turret_Detach = true;
force OPTRE_Hijack_FriendlyFireEnabled = false;
force OPTRE_Hijack_Mode = 0;
force OPTRE_Human_Non_Detachable_Turrets = "";
force OPTRE_Jackal_Randomize = true;
force OPTRE_Spartan_Non_Detachable_Turrets = "";
force OPTRE_Spartan_Randomize = true;

// TFAR - Clientside settings
TFAR_curatorCamEars = false;
TFAR_default_radioVolume = 7;
TFAR_intercomDucking = 0.2;
TFAR_intercomVolume = 0.1;
force TFAR_moveWhileTabbedOut = true;
TFAR_noAutomoveSpectator = false;
force TFAR_oldVolumeHint = true;
TFAR_pluginTimeout = 4;
TFAR_PosUpdateMode = 0.1;
force TFAR_showChannelChangedHint = true;
force TFAR_ShowDiaryRecord = false;
force TFAR_showTransmittingHint = true;
TFAR_ShowVolumeHUD = false;
TFAR_splendidCamEars = false;
TFAR_tangentReleaseDelay = 0;
TFAR_VolumeHudTransparency = 0;
TFAR_volumeModifier_forceSpeech = false;

// TFAR - Global settings
force TFAR_AICanHearPlayer = true;
force TFAR_AICanHearSpeaker = true;
force TFAR_allowDebugging = false;
tfar_core_noTSNotConnectedHint = false;
force TFAR_defaultIntercomSlot = -0.857932;
force TFAR_disableAutoMute = true;
force TFAR_enableIntercom = true;
force TFAR_experimentalVehicleIsolation = true;
force TFAR_externalIntercomEnable = 1;
force TFAR_externalIntercomMaxRange_Phone = 5;
force TFAR_externalIntercomMaxRange_Wireless = 15;
force TFAR_fullDuplex = true;
force TFAR_giveLongRangeRadioToGroupLeaders = false;
force TFAR_giveMicroDagrToSoldier = false;
force TFAR_givePersonalRadioToRegularSoldier = false;
force TFAR_globalRadioRangeCoef = 1;
force TFAR_instantiate_instantiateAtBriefing = false;
force TFAR_objectInterceptionEnabled = true;
force TFAR_objectInterceptionStrength = 400;
force tfar_radiocode_east = "_opfor";
force tfar_radiocode_independent = "_independent";
force tfar_radiocode_west = "_bluefor";
force tfar_radioCodesDisabled = true;
force TFAR_SameLRFrequenciesForSide = false;
force TFAR_SameSRFrequenciesForSide = false;
force TFAR_setting_defaultFrequencies_lr_east = "";
force TFAR_setting_defaultFrequencies_lr_independent = "";
force TFAR_setting_defaultFrequencies_lr_west = "";
force TFAR_setting_defaultFrequencies_sr_east = "";
force TFAR_setting_defaultFrequencies_sr_independent = "";
force TFAR_setting_defaultFrequencies_sr_west = "";
force TFAR_setting_DefaultRadio_Airborne_east = "TFAR_mr6000l";
force TFAR_setting_DefaultRadio_Airborne_Independent = "TFAR_anarc164";
force TFAR_setting_DefaultRadio_Airborne_West = "TFAR_anarc210";
force TFAR_setting_DefaultRadio_Backpack_east = "TFAR_mr3000";
force TFAR_setting_DefaultRadio_Backpack_Independent = "TFAR_anprc155";
force TFAR_setting_DefaultRadio_Backpack_west = "TFAR_rt1523g";
force TFAR_setting_DefaultRadio_Personal_east = "TFAR_fadak";
force TFAR_setting_DefaultRadio_Personal_Independent = "TFAR_anprc148jem";
force TFAR_setting_DefaultRadio_Personal_West = "TFAR_anprc152";
force TFAR_setting_DefaultRadio_Rifleman_East = "TFAR_pnr1000a";
force TFAR_setting_DefaultRadio_Rifleman_Independent = "TFAR_anprc154";
force TFAR_setting_DefaultRadio_Rifleman_West = "TFAR_rf7800str";
force TFAR_setting_externalIntercomWirelessHeadgear = "";
force TFAR_spectatorCanHearEnemyUnits = true;
force TFAR_spectatorCanHearFriendlies = true;
force TFAR_takingRadio = 2;
force TFAR_Teamspeak_Channel_Name = "ARCATFAR";
force TFAR_Teamspeak_Channel_Password = "Arca";
force tfar_terrain_interception_coefficient = 7;
force TFAR_voiceCone = true;

// WebKnight Droids
force WBK_Droid_b1_damage = "4";
force WBK_Droid_b2_damage = "120";

// Zeus Enhanced
force zen_area_markers_editableMarkers = 0;
force zen_building_markers_enabled = false;
zen_camera_adaptiveSpeed = true;
zen_camera_defaultSpeedCoef = 1;
zen_camera_fastSpeedCoef = 1;
zen_camera_followTerrain = true;
force zen_common_ascensionMessages = false;
force zen_common_autoAddObjects = true;
force zen_common_cameraBird = false;
zen_common_darkMode = false;
force zen_common_disableGearAnim = true;
force zen_common_preferredArsenal = 1;
force zen_compat_ace_hideModules = false;
zen_context_menu_enabled = 2;
zen_context_menu_overrideWaypoints = false;
force zen_editor_addGroupIcons = true;
zen_editor_addModIcons = false;
force zen_editor_declutterEmptyTree = false;
force zen_editor_disableLiveSearch = true;
zen_editor_moveDisplayToEdge = true;
force zen_editor_parachuteSounds = true;
zen_editor_previews_enabled = true;
zen_editor_randomizeCopyPaste = false;
force zen_editor_removeWatermark = true;
force zen_editor_unitRadioMessages = 2;
force zen_placement_enabled = true;
zen_remote_control_cameraExitPosition = 2;
force zen_visibility_enabled = 0;
zen_visibility_maxDistance = 5000;
force zen_vision_enableBlackHot = true;
zen_vision_enableBlackHotGreenCold = false;
zen_vision_enableBlackHotRedCold = false;
zen_vision_enableGreenHotCold = false;
force zen_vision_enableNVG = true;
zen_vision_enableRedGreenThermal = false;
zen_vision_enableRedHotCold = false;
force zen_vision_enableWhiteHot = true;
zen_vision_enableWhiteHotRedCold = false;

// Zeus Enhanced - Attributes
zen_attributes_enableAbilities = true;
zen_attributes_enableAmmo = true;
zen_attributes_enableArsenal = true;
zen_attributes_enableBuildingMarker = true;
zen_attributes_enableDamage = true;
zen_attributes_enableEngine = true;
zen_attributes_enableExecute = true;
zen_attributes_enableFuel = true;
zen_attributes_enableGarage = true;
zen_attributes_enableGroupBehaviour = true;
zen_attributes_enableGroupCombatMode = true;
zen_attributes_enableGroupExecute = true;
zen_attributes_enableGroupFormation = true;
zen_attributes_enableGroupID = true;
zen_attributes_enableGroupSide = true;
zen_attributes_enableGroupSkill = true;
zen_attributes_enableGroupSpeed = true;
zen_attributes_enableGroupStance = true;
zen_attributes_enableHealth = true;
zen_attributes_enableInventory = true;
zen_attributes_enableLights = true;
zen_attributes_enableMarkerAlpha = true;
zen_attributes_enableMarkerColor = true;
zen_attributes_enableMarkerText = true;
zen_attributes_enableName = true;
zen_attributes_enablePlateNumber = true;
zen_attributes_enableRank = true;
zen_attributes_enableRespawnPosition = true;
zen_attributes_enableRespawnVehicle = true;
zen_attributes_enableSensors = true;
zen_attributes_enableSkill = true;
zen_attributes_enableSkills = true;
zen_attributes_enableStance = true;
zen_attributes_enableStates = true;
zen_attributes_enableTraits = true;
zen_attributes_enableVehicleLock = true;
zen_attributes_enableWaypointBehaviour = true;
zen_attributes_enableWaypointCombatMode = true;
zen_attributes_enableWaypointFormation = true;
zen_attributes_enableWaypointLoiterAltitude = true;
zen_attributes_enableWaypointLoiterDirection = true;
zen_attributes_enableWaypointLoiterRadius = true;
zen_attributes_enableWaypointSpeed = true;
zen_attributes_enableWaypointTimeout = true;
zen_attributes_enableWaypointType = true;

// Zeus Enhanced - Faction Filter
zen_faction_filter_0_3AS_CIS = true;
zen_faction_filter_0_3AS_Rebel = true;
zen_faction_filter_0_JLTS_CIS = true;
zen_faction_filter_0_LS_CIS = true;
zen_faction_filter_0_LS_PIRATES = true;
zen_faction_filter_0_lsi_redfor_strmc = true;
zen_faction_filter_0_LSI_STRMC = true;
zen_faction_filter_0_mti_factions_bns = true;
zen_faction_filter_0_mti_factions_cis = true;
zen_faction_filter_0_mti_factions_revanites = true;
zen_faction_filter_0_NCA_categoryPyrishiCollective = true;
zen_faction_filter_0_NCA_categorySeparatistArmy = true;
zen_faction_filter_0_OPF_F = true;
zen_faction_filter_0_OPF_G_F = true;
zen_faction_filter_0_OPF_GEN_F = true;
zen_faction_filter_0_OPF_R_F = true;
zen_faction_filter_0_OPF_T_F = true;
zen_faction_filter_0_OPTRE_FC_Covenant = true;
zen_faction_filter_0_OPTRE_Ins = true;
zen_faction_filter_0_OPTRE_Ins_groups = true;
zen_faction_filter_0_SSV_Aux_Replikas = true;
zen_faction_filter_0_WBK_AI = true;
zen_faction_filter_0_WBK_AI_Melee = true;
zen_faction_filter_0_WBK_AI_StarWars_Droids = true;
zen_faction_filter_0_WBK_Droid_groups = true;
zen_faction_filter_1_3AS_Imperial = true;
zen_faction_filter_1_3AS_Rep = true;
zen_faction_filter_1_BLU_blk_hal_androids_F = true;
zen_faction_filter_1_BLU_CTRG_F = true;
zen_faction_filter_1_BLU_F = true;
zen_faction_filter_1_BLU_G_F = true;
zen_faction_filter_1_BLU_GEN_F = true;
zen_faction_filter_1_BLU_hal_androids_F = true;
zen_faction_filter_1_BLU_T_F = true;
zen_faction_filter_1_BLU_W_F = true;
zen_faction_filter_1_BLU_W_hal_androids_F = true;
zen_faction_filter_1_DSA_DeltaX = true;
zen_faction_filter_1_DSA_DeltaX_groups = true;
zen_faction_filter_1_IND_G_F = true;
zen_faction_filter_1_JLTS_GAR = true;
zen_faction_filter_1_LS_CSF = true;
zen_faction_filter_1_LS_GAR = true;
zen_faction_filter_1_LS_ORSF = true;
zen_faction_filter_1_LS_REPNAVY = true;
zen_faction_filter_1_lsb_turret = true;
zen_faction_filter_1_mti_faction_SOB = true;
zen_faction_filter_1_NCA_categoryGalacticRepublic = true;
zen_faction_filter_1_OPTRE_UNSC = true;
zen_faction_filter_1_PhoenixArmoury_Faction = true;
zen_faction_filter_1_PhoenixCore_Faction = true;
zen_faction_filter_1_SSV_Aux_Androids = true;
zen_faction_filter_1_SWLB_GAR = true;
zen_faction_filter_1_SWLB_GAR_SOB = true;
zen_faction_filter_1_TKE_UCN_Drop_Pods = true;
zen_faction_filter_1_WBK_AI = true;
zen_faction_filter_1_WBK_AI_Melee = true;
zen_faction_filter_2_IND_C_F = true;
zen_faction_filter_2_IND_E_F = true;
zen_faction_filter_2_IND_F = true;
zen_faction_filter_2_IND_G_F = true;
zen_faction_filter_2_IND_L_F = true;
zen_faction_filter_2_LS_MANDALORIAN = true;
zen_faction_filter_2_LS_MEMEFOR = true;
zen_faction_filter_2_LS_MERC = true;
zen_faction_filter_2_mti_factions_jarotsad = true;
zen_faction_filter_2_OPTRE_CAA = true;
zen_faction_filter_2_OPTRE_DME = true;
zen_faction_filter_2_OPTRE_FC_Covenant = true;
zen_faction_filter_2_OPTRE_Ins = true;
zen_faction_filter_2_OPTRE_Ins_groups = true;
zen_faction_filter_2_OPTRE_PD = true;
zen_faction_filter_2_OPTRE_UEG_Civ = true;
zen_faction_filter_3_3AS_Civilian = true;
zen_faction_filter_3_CIV_F = true;
zen_faction_filter_3_CIV_IDAP_F = true;
zen_faction_filter_3_DSA_Spooks = true;
zen_faction_filter_3_IND_L_F = true;
zen_faction_filter_3_LS_CIV = true;
zen_faction_filter_3_OPTRE_UEG_Civ = true;
